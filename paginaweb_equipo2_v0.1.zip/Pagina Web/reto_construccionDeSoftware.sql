-- Reto Construcción de Software
-- Equipo 2

-- CREACION DE LA BASE DE DATOS
-- CREATE DATABASE reto_ConstrucciónDeSoftware;
-- FIN DE CREACION DE LA BASE DE DATOS

-- CREACION DE TABLAS
CREATE TABLE pais(
	id_pais int,
	pais varchar(50),
	PRIMARY KEY(id_pais)
);

CREATE TABLE estado(
	id_estado int,
	estado varchar(50),
	PRIMARY KEY(id_estado)
);

CREATE TABLE sexo(
	id_sexo int,
	sexo varchar(10),
	PRIMARY KEY(id_sexo)
);

CREATE TABLE color(
	id_color int,
	color varchar(8),
	PRIMARY KEY(id_color)
);

CREATE TABLE especialidad(
	id_especialidad int,
	especialidad varchar(50),
	PRIMARY KEY(id_especialidad)
);

CREATE TABLE autor(
	id_autor int,
	nombre varchar(100),
	apellido_paterno varchar(50),
	apellido_materno varchar(50),
	correo_electronico varchar(50),
	contraseña varchar(50),
	id_iepam int,
	fecha_de_nacimiento date,
	fecha_de_ingreso timestamp,
	id_pais int,
	id_estado int,
	id_sexo int,
	id_especialidad int,
	contacto_telefono_trabajo varchar(10),
	contacto_correo_electronico_trabajo varchar(100),
	contacto_otro varchar(256),
	seguidores int,
	comentarios varchar(256),
	historial_académico varchar(1000),
	experiencia_laboral varchar(1000),
	certificaciones varchar(1000),
	idiomas varchar(1000),
	habilidades varchar(1000),
	PRIMARY KEY(id_autor),
	FOREIGN KEY(id_pais) REFERENCES pais(id_pais),
	FOREIGN KEY(id_estado) REFERENCES estado(id_estado),
	FOREIGN KEY(id_sexo) REFERENCES sexo(id_sexo),
	FOREIGN KEY(id_especialidad) REFERENCES especialidad(id_especialidad),
	UNIQUE(correo_electronico)
);

CREATE TABLE interes(
	id_interes int,
	id_color int,
	interes varchar(50),
	descripcion varchar(256),
	PRIMARY KEY(id_interes),
	FOREIGN KEY(id_color) REFERENCES color(id_color)
);

CREATE TABLE pagina(
	id_pagina int,
	id_autor int,
	id_interes int,
	video varchar(256),
	descripcion varchar(256),
	PRIMARY KEY(id_pagina),
	FOREIGN KEY(id_autor) REFERENCES autor(id_autor),
	FOREIGN KEY(id_interes) REFERENCES interes(id_interes)
);

CREATE TABLE usuario(
	id_usuario int,
	nombre varchar(100),
	apellido_paterno varchar(50),
	apellido_materno varchar(50),
	nickname_usuario varchar(50),
	contraseña varchar(50),
	correo_electronico varchar(50),
	fecha_de_nacimiento date,
	fecha_de_ingreso timestamp,
	id_pais int,
	id_estado int,
	id_sexo int,
	comentarios varchar(256),
	PRIMARY KEY(id_usuario),
	FOREIGN KEY(id_pais) REFERENCES pais(id_pais),
	FOREIGN KEY(id_estado) REFERENCES estado(id_estado),
	FOREIGN KEY(id_sexo) REFERENCES sexo(id_sexo),
	UNIQUE(nickname_usuario),
	UNIQUE(correo_electronico)
);

CREATE TABLE usuario_interes(
	id_usuario int,
	id_interes int,
	FOREIGN KEY(id_usuario) REFERENCES usuario(id_usuario),
	FOREIGN KEY(id_interes) REFERENCES interes(id_interes)
);

CREATE TABLE usuario_marcadores_paginas(
	id_usuario int,
	id_pagina int,
	marcador_comentario varchar(256),
	FOREIGN KEY(id_usuario) REFERENCES usuario(id_usuario),
	FOREIGN KEY(id_pagina) REFERENCES pagina(id_pagina)
);
-- FIN DE CREACION DE TABLAS

--INSERT PAISES
INSERT INTO pais(id_pais,pais)
VALUES (1,'Mexico');
--INSERT ESTADOS
INSERT INTO estado(id_estado,estado)
VALUES (1,'Aguascalientes');
INSERT INTO estado(id_estado,estado)
VALUES (2,'Baja California');
INSERT INTO estado(id_estado,estado)
VALUES (3,'Baja California Sur');
INSERT INTO estado(id_estado,estado)
VALUES (4,'Campeche');
INSERT INTO estado(id_estado,estado)
VALUES (5,'Chiapas');
INSERT INTO estado(id_estado,estado)
VALUES (6,'Chihuahua');
INSERT INTO estado(id_estado,estado)
VALUES (7,'Coahuila');
INSERT INTO estado(id_estado,estado)
VALUES (8,'Colima');
INSERT INTO estado(id_estado,estado)
VALUES (9,'Ciudad de México / CDMX');
INSERT INTO estado(id_estado,estado)
VALUES (10,'Durango');
INSERT INTO estado(id_estado,estado)
VALUES (11,'Estado de México');
INSERT INTO estado(id_estado,estado)
VALUES (12,'Guanajuato');
INSERT INTO estado(id_estado,estado)
VALUES (13,'Guerrero');
INSERT INTO estado(id_estado,estado)
VALUES (14,'Hidalgo');
INSERT INTO estado(id_estado,estado)
VALUES (15,'Jalisco');
INSERT INTO estado(id_estado,estado)
VALUES (16,'Michoacán');
INSERT INTO estado(id_estado,estado)
VALUES (17,'Morelos');
INSERT INTO estado(id_estado,estado)
VALUES (18,'Nayarit');
INSERT INTO estado(id_estado,estado)
VALUES (19,'Nuevo León');
INSERT INTO estado(id_estado,estado)
VALUES (20,'Oaxaca');
INSERT INTO estado(id_estado,estado)
VALUES (21,'Puebla');
INSERT INTO estado(id_estado,estado)
VALUES (22,'Querétaro');
INSERT INTO estado(id_estado,estado)
VALUES (23,'Quintana Roo');
INSERT INTO estado(id_estado,estado)
VALUES (24,'San Luis Potosí');
INSERT INTO estado(id_estado,estado)
VALUES (25,'Sinaloa');
INSERT INTO estado(id_estado,estado)
VALUES (26,'Sonora');
INSERT INTO estado(id_estado,estado)
VALUES (27,'Tabasco');
INSERT INTO estado(id_estado,estado)
VALUES (28,'Tamaulipas');
INSERT INTO estado(id_estado,estado)
VALUES (29,'Tlaxcala');
INSERT INTO estado(id_estado,estado)
VALUES (30,'Veracruz');
INSERT INTO estado(id_estado,estado)
VALUES (31,'Yucatán');
INSERT INTO estado(id_estado,estado)
VALUES (32,'Zacatecas');
--INSERT SEXO
INSERT INTO sexo(id_sexo,sexo)
VALUES (1,'Masculino');
INSERT INTO sexo(id_sexo,sexo)
VALUES (2,'Femenino');
INSERT INTO sexo(id_sexo,sexo)
VALUES (3,'Otro');

--Sequence
	--ID Usuario
CREATE SEQUENCE IF NO EXISTS user_id
START WITH 1000
INCREMENT BY 1;

	--ID Autor
CREATE SEQUENCE IF NO EXISTS autor_id
START WITH 0
INCREMENT BY 1;

--SP
	--Nuevo usuario
CREATE OR REPLACE PROCEDURE nuevo_usuario(nombre varchar(100),apellido_paterno varchar(50),apellido_materno varchar(50),sexo varchar(10),
								correo_electronico varchar(50),nickname_usuario varchar(50),
								contraseña varchar(50),fecha_de_nacimiento date,pais varchar(50),estado varchar(50))
AS $$
	INSERT INTO usuario
	VALUES (user_id,nombre,apellido_paterno,apellido_materno,nickname_usuario,contraseña,correo_electronico,fecha_de_nacimiento,
				GETDATE(),pais.id_pais,estado.id_estado,sexo.id_sexo,'',)
$$ LANGUAGE SQL;

	--Nuevo autor
CREATE OR REPLACE PROCEDURE nuevo_autor(nombre varchar(100),apellido_paterno varchar(50),apellido_materno varchar(50),sexo varchar(10),
								correo_electronico varchar(50),nickname_usuario varchar(50),contraseña varchar(50),
								id_iepam int,fecha_de_nacimiento date,pais varchar(50),estado varchar(50))
AS $$
	INSERT INTO usuario
	VALUES (autor_id,nombre,apellido_paterno,apellido_materno,correo_electronico,contraseña,id_iepam,fecha_de_nacimiento,
			GETDATE(),pais.id_pais,estado.id_estado,sexo.id_sexo,0,'','','',0,'','','','','','')
$$ LANGUAGE SQL;

--Funciones


--Views
	--Vista perfil del autor
CREATE VIEW perfil AS
SELECT nombre,apellido_paterno,apellido_materno,contacto_correo_electronico_trabajo,especialidad.especialidad,historial_académico,
		experiencia_laboral,certificaciones,idiomas,habilidades.
FROM autor
JOIN especialidad on autor.id_especialidad = especialidad.id_especialidad;